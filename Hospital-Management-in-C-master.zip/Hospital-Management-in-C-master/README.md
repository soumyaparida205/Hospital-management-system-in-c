# Hospital-Management-in-C

A complete Hospital Management System written in C Programming Language.

TAKE CARE TO NOT MISS ANY INPUT, IT CAN'T BE UNDONE, Unfortunately.

For Any Queries and/or Issues related to the Code, I would be more than Happy to Listen and Improve the same. 

Attaching some ScreenShots for Reference.

Thank You.
