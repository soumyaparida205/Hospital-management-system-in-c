#include<stdio.h>

void header()
{
	printf("\n\n\n\n\n\n\t\t\t\t***HOSPITAL MANAGEMENT SYSTEM IN C***\n\n\n");		
}


void intro()
{
	header();
	printf("\t\tBY : TejasSheth\n\n\n");            
    printf("\t\t\tThis Course would span upto 4 weeks from Start.\n");
}



void main()
{
	intro();
	int i;
	for (i = 0; i < 100; i++)
{
	printf("\n");
}
}

